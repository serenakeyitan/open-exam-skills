# Infographic Skill - Standalone Package

Generate professional horizontal infographics using Nano Banana Pro (Gemini 3 Pro Image).

## Quick Start

1. **Run setup script:**
   ```bash
   bash setup.sh
   ```

2. **Set your Gemini API key:**
   ```bash
   export GEMINI_API_KEY="your_actual_api_key_here"
   ```

   Or create a `.env` file:
   ```bash
   echo "GEMINI_API_KEY=your_actual_api_key_here" > .env
   ```

3. **Test it:**
   ```bash
   python main.py --test
   ```

4. **Generate infographic:**
   ```bash
   python main.py --input your_content.txt --output infographic.png
   ```

## Get API Key

Get your free Gemini API key at: https://aistudio.google.com/apikey

## Documentation

- `SETUP.md` - Detailed setup instructions and troubleshooting
- `SKILL.md` - Skill documentation and usage examples
- `README.md` - Original README

## Support

This is part of the NotebookLM Skills Suite.
Repository: https://github.com/serenakeyitan/nblm-skills
