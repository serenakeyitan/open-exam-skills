#!/bin/bash
# Setup script for infographic skill

echo "Setting up Infographic Skill..."
echo ""

# Check Python version
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 is not installed"
    exit 1
fi

echo "✓ Python 3 found"

# Install dependencies
echo ""
echo "Installing dependencies..."
pip install -q -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed successfully"
else
    echo "❌ Error: Failed to install dependencies"
    exit 1
fi

# Check for API key
echo ""
if [ -z "$GEMINI_API_KEY" ] && [ ! -f ".env" ]; then
    echo "⚠️  WARNING: GEMINI_API_KEY not found!"
    echo ""
    echo "You need to set your Gemini API key before using this skill."
    echo ""
    echo "Option 1: Create .env file (recommended for local use)"
    echo "  echo 'GEMINI_API_KEY=your_key_here' > .env"
    echo ""
    echo "Option 2: Set environment variable (recommended for sandbox)"
    echo "  export GEMINI_API_KEY='your_key_here'"
    echo ""
    echo "Get your API key at: https://aistudio.google.com/apikey"
    echo ""
else
    echo "✓ API key configuration found"
fi

echo ""
echo "✓ Setup complete!"
echo ""
echo "To test:"
echo "  python main.py --test"
echo ""
echo "To generate an infographic:"
echo "  python main.py --input your_content.txt --output infographic.png"
echo ""
echo "For more information, see SETUP.md"
